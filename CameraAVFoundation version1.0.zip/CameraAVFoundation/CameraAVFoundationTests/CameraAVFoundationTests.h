//
//  CameraAVFoundationTests.h
//  CameraAVFoundationTests
//
//  Created by Jorge Paiz on 8/31/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface CameraAVFoundationTests : SenTestCase {
@private
    
}

@end
